# Resume Builder Pro - Full Stack Application

A complete full-stack resume builder application with React frontend and Express backend.

## Features

### Frontend
- Modern React application with TypeScript
- Responsive design with Tailwind CSS
- Multiple resume templates
- Real-time resume editing
- PDF generation
- Resume management dashboard

### Backend
- Express.js REST API
- In-memory data storage
- CORS enabled
- CRUD operations for resumes
- PDF generation endpoints

## Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

### Running the Application

#### Option 1: Run Frontend and Backend Separately

**Start the backend server:**
```bash
npm run server
```

**Start the frontend development server:**
```bash
npm run dev
```

#### Option 2: Run Both Together
```bash
npm run dev:full
```

The application will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:3001

## Project Structure

```
├── src/
│   ├── pages/           # React page components
│   │   ├── Home.tsx     # Landing page
│   │   ├── Dashboard.tsx # Resume management
│   │   ├── ResumeBuilder.tsx # Resume editor
│   │   └── Templates.tsx # Template gallery
│   ├── App.tsx         # Main app with routing
│   └── main.tsx        # App entry point
├── server.js           # Express backend server
├── package.json        # Dependencies and scripts
└── README.md          # This file
```

## API Endpoints

### Resumes
- `GET /api/resumes` - Get all resumes
- `GET /api/resumes/:id` - Get single resume
- `POST /api/resumes` - Create new resume
- `PUT /api/resumes/:id` - Update resume
- `DELETE /api/resumes/:id` - Delete resume
- `POST /api/resumes/:id/generate-pdf` - Generate PDF

### Health Check
- `GET /api/health` - Server health status

## Features in Detail

### Resume Builder
- Personal information section
- Work experience management
- Education history
- Skills with proficiency levels
- Projects and certifications
- Real-time preview

### Dashboard
- View all resumes
- Edit existing resumes
- Download as PDF
- Delete resumes
- Resume statistics

### Templates
- Professional templates
- Creative designs
- Academic layouts
- Tech-focused designs
- ATS-optimized formats

## Technologies Used

### Frontend
- React 19
- TypeScript
- Tailwind CSS
- React Router DOM
- React Hook Form
- Axios for API calls
- Lucide React for icons

### Backend
- Express.js
- CORS middleware
- UUID for ID generation

## Development

### Adding New Features
1. Create new React components in `src/pages/` or `src/components/`
2. Add API endpoints in `server.js`
3. Update routing in `src/App.tsx`

### Styling
- Uses Tailwind CSS utility classes
- Custom styles in `src/index.css`
- Responsive design with mobile-first approach

## Deployment

### Frontend
Build for production:
```bash
npm run build
```

### Backend
Deploy `server.js` to any Node.js hosting service (Render, Railway, Heroku, etc.)

## License

MIT

## Support

For issues and feature requests, please create an issue in the repository.
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Home } from './pages/Home';
import { ResumeBuilder } from './pages/ResumeBuilder';
import { Dashboard } from './pages/Dashboard';
import { Templates } from './pages/Templates';
import { FileText, Home as HomeIcon, LayoutDashboard, Palette } from 'lucide-react';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        {/* Navigation */}
        <nav className="bg-white shadow-lg border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <div className="flex items-center space-x-2">
                  <FileText className="h-8 w-8 text-blue-600" />
                  <span className="text-2xl font-bold text-gray-900">ResumeBuilder Pro</span>
                </div>
              </div>
              <div className="flex items-center space-x-8">
                <Link to="/" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-colors">
                  <HomeIcon className="h-5 w-5" />
                  <span>Home</span>
                </Link>
                <Link to="/dashboard" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-colors">
                  <LayoutDashboard className="h-5 w-5" />
                  <span>Dashboard</span>
                </Link>
                <Link to="/templates" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-colors">
                  <Palette className="h-5 w-5" />
                  <span>Templates</span>
                </Link>
                <Link to="/builder" className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors">
                  Create Resume
                </Link>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/builder" element={<ResumeBuilder />} />
            <Route path="/builder/:id" element={<ResumeBuilder />} />
            <Route path="/templates" element={<Templates />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-gray-200 mt-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center text-gray-600">
              <p>© 2024 ResumeBuilder Pro. All rights reserved.</p>
              <p className="mt-2 text-sm">Build professional resumes with ease</p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
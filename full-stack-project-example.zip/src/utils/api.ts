import axios from 'axios';

const API_URL = 'http://localhost:3001/api';

export const api = {
  // Resumes
  getResumes: () => axios.get(`${API_URL}/resumes`),
  getResume: (id: string) => axios.get(`${API_URL}/resumes/${id}`),
  createResume: (data: any) => axios.post(`${API_URL}/resumes`, data),
  updateResume: (id: string, data: any) => axios.put(`${API_URL}/resumes/${id}`, data),
  deleteResume: (id: string) => axios.delete(`${API_URL}/resumes/${id}`),
  generatePDF: (id: string) => axios.post(`${API_URL}/resumes/${id}/generate-pdf`),
  
  // Health check
  healthCheck: () => axios.get(`${API_URL}/health`)
};
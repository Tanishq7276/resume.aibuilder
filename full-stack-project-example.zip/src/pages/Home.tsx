import { Link } from 'react-router-dom';
import { CheckCircle, FileText, Zap, Shield } from 'lucide-react';

export function Home() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="text-center py-12">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          Build Your Perfect Resume in <span className="text-blue-600">Minutes</span>
        </h1>
        <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
          Create professional resumes that get you noticed. Our AI-powered builder helps you craft the perfect resume for any job.
        </p>
        <div className="flex justify-center space-x-4">
          <Link 
            to="/builder" 
            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Zap className="h-5 w-5" />
            <span>Start Building Free</span>
          </Link>
          <Link 
            to="/templates" 
            className="bg-white text-gray-800 px-8 py-3 rounded-lg font-semibold text-lg border border-gray-300 hover:bg-gray-50 transition-colors"
          >
            Browse Templates
          </Link>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-200">
          <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <FileText className="h-6 w-6 text-blue-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-3">Professional Templates</h3>
          <p className="text-gray-600">Choose from dozens of professionally designed templates that impress recruiters.</p>
        </div>
        
        <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-200">
          <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <Zap className="h-6 w-6 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-3">AI-Powered Suggestions</h3>
          <p className="text-gray-600">Get intelligent suggestions to improve your resume content and formatting.</p>
        </div>
        
        <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-200">
          <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <Shield className="h-6 w-6 text-purple-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-3">Secure & Private</h3>
          <p className="text-gray-600">Your data is encrypted and secure. You own all your resume content.</p>
        </div>
      </div>

      {/* Benefits */}
      <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Why Choose ResumeBuilder Pro?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            "ATS-friendly templates that pass resume scanners",
            "Real-time preview as you build",
            "Export to PDF, Word, and plain text",
            "Multiple resume versions management",
            "Industry-specific examples",
            "Mobile-friendly editing"
          ].map((benefit, index) => (
            <div key={index} className="flex items-start space-x-3">
              <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0 mt-1" />
              <span className="text-gray-700">{benefit}</span>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="text-center py-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Land Your Dream Job?</h2>
        <p className="text-gray-600 mb-8">Join thousands of successful job seekers who got hired with our resumes.</p>
        <Link 
          to="/builder" 
          className="inline-flex items-center justify-center bg-gradient-to-r from-blue-600 to-purple-600 text-white px-10 py-4 rounded-lg font-bold text-lg hover:opacity-90 transition-opacity"
        >
          Create Your Resume Now
        </Link>
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Save, Download, Eye, Plus, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import axios from 'axios';

const API_URL = 'http://localhost:3001/api';

interface PersonalInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  linkedin: string;
  github: string;
  portfolio: string;
  summary: string;
}

interface Experience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string;
  current: boolean;
}

interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa: string;
}

interface Skill {
  id: string;
  name: string;
  level: string;
}

interface Project {
  id: string;
  name: string;
  description: string;
  technologies: string;
  url: string;
}

interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
  url: string;
}

interface ResumeData {
  id: string;
  personalInfo: PersonalInfo;
  experience: Experience[];
  education: Education[];
  skills: Skill[];
  projects: Project[];
  certifications: Certification[];
}

export function ResumeBuilder() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [resume, setResume] = useState<ResumeData | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeSection, setActiveSection] = useState('personal');
  const [previewMode, setPreviewMode] = useState(false);

  const { register, handleSubmit, reset } = useForm();

  useEffect(() => {
    if (id) {
      loadResume(id);
    } else {
      // Initialize new resume
      setResume({
        id: '',
        personalInfo: {
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          address: '',
          city: '',
          state: '',
          zipCode: '',
          linkedin: '',
          github: '',
          portfolio: '',
          summary: ''
        },
        experience: [],
        education: [],
        skills: [],
        projects: [],
        certifications: []
      });
    }
  }, [id]);

  const loadResume = async (resumeId: string) => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/resumes/${resumeId}`);
      setResume(response.data);
      reset(response.data.personalInfo);
    } catch (error) {
      console.error('Error loading resume:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveResume = async (data: any) => {
    try {
      setLoading(true);
      const resumeData = {
        ...resume,
        personalInfo: data
      };

      if (id) {
        await axios.put(`${API_URL}/resumes/${id}`, resumeData);
      } else {
        const response = await axios.post(`${API_URL}/resumes`, resumeData);
        navigate(`/builder/${response.data.id}`);
      }
      
      alert('Resume saved successfully!');
    } catch (error) {
      console.error('Error saving resume:', error);
      alert('Error saving resume');
    } finally {
      setLoading(false);
    }
  };

  const generatePDF = async () => {
    if (!resume?.id) return;
    
    try {
      const response = await axios.post(`${API_URL}/resumes/${resume.id}/generate-pdf`);
      alert(response.data.message);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF');
    }
  };

  const addExperience = () => {
    const newExp: Experience = {
      id: Date.now().toString(),
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      description: '',
      current: false
    };
    setResume(prev => prev ? {
      ...prev,
      experience: [...prev.experience, newExp]
    } : null);
  };

  const addEducation = () => {
    const newEdu: Education = {
      id: Date.now().toString(),
      institution: '',
      degree: '',
      field: '',
      startDate: '',
      endDate: '',
      gpa: ''
    };
    setResume(prev => prev ? {
      ...prev,
      education: [...prev.education, newEdu]
    } : null);
  };

  const addSkill = () => {
    const newSkill: Skill = {
      id: Date.now().toString(),
      name: '',
      level: 'Intermediate'
    };
    setResume(prev => prev ? {
      ...prev,
      skills: [...prev.skills, newSkill]
    } : null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">
          {id ? 'Edit Resume' : 'Create New Resume'}
        </h1>
        <div className="flex space-x-4">
          <button
            onClick={() => setPreviewMode(!previewMode)}
            className="flex items-center space-x-2 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Eye className="h-5 w-5" />
            <span>{previewMode ? 'Edit Mode' : 'Preview Mode'}</span>
          </button>
          <button
            onClick={handleSubmit(saveResume)}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Save className="h-5 w-5" />
            <span>Save Resume</span>
          </button>
          <button
            onClick={generatePDF}
            className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download className="h-5 w-5" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Sidebar - Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Resume Sections</h3>
            <div className="space-y-2">
              {['personal', 'experience', 'education', 'skills', 'projects', 'certifications'].map((section) => (
                <button
                  key={section}
                  onClick={() => setActiveSection(section)}
                  className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                    activeSection === section
                      ? 'bg-blue-100 text-blue-700'
                      : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="capitalize">{section}</span>
                    {activeSection === section ? (
                      <ChevronUp className="h-4 w-4" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2">
          {previewMode ? (
            <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Resume Preview</h2>
              {/* Preview content would go here */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Personal Information</h3>
                  <p className="text-gray-600">Preview of your resume will appear here</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Personal Information */}
              {activeSection === 'personal' && (
                <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Personal Information</h3>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          First Name *
                        </label>
                        <input
                          {...register('firstName', { required: true })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="John"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Last Name *
                        </label>
                        <input
                          {...register('lastName', { required: true })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Doe"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email *
                        </label>
                        <input
                          {...register('email', { required: true })}
                          type="email"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="john.doe@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Phone *
                        </label>
                        <input
                          {...register('phone', { required: true })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="(123) 456-7890"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Professional Summary
                      </label>
                      <textarea
                        {...register('summary')}
                        rows={4}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Experienced software developer with 5+ years in web development..."
                      />
                    </div>
                  </form>
                </div>
              )}

              {/* Experience */}
              {activeSection === 'experience' && (
                <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-900">Work Experience</h3>
                    <button
                      onClick={addExperience}
                      className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Plus className="h-5 w-5" />
                      <span>Add Experience</span>
                    </button>
                  </div>
                  
                  {resume?.experience.map((exp, index) => (
                    <div key={exp.id} className="border border-gray-200 rounded-lg p-6 mb-4">
                      <div className="flex justify-between items-start mb-4">
                        <h4 className="text-lg font-medium text-gray-900">Experience #{index + 1}</h4>
                        <button
                          onClick={() => {
                            setResume(prev => prev ? {
                              ...prev,
                              experience: prev.experience.filter(e => e.id !== exp.id)
                            } : null);
                          }}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <input
                            placeholder="Company Name"
                            className="px-4 py-2 border border-gray-300 rounded-lg"
                            value={exp.company}
                            onChange={(e) => {
                              const newExp = [...resume.experience];
                              newExp[index].company = e.target.value;
                              setResume({...resume, experience: newExp});
                            }}
                          />
                          <input
                            placeholder="Position"
                            className="px-4 py-2 border border-gray-300 rounded-lg"
                            value={exp.position}
                            onChange={(e) => {
                              const newExp = [...resume.experience];
                              newExp[index].position = e.target.value;
                              setResume({...resume, experience: newExp});
                            }}
                          />
                        </div>
                        <textarea
                          placeholder="Description of your responsibilities and achievements"
                          rows={3}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          value={exp.description}
                          onChange={(e) => {
                            const newExp = [...resume.experience];
                            newExp[index].description = e.target.value;
                            setResume({...resume, experience: newExp});
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Education */}
              {activeSection === 'education' && (
                <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-900">Education</h3>
                    <button
                      onClick={addEducation}
                      className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Plus className="h-5 w-5" />
                      <span>Add Education</span>
                    </button>
                  </div>
                  
                  {resume?.education.map((edu, index) => (
                    <div key={edu.id} className="border border-gray-200 rounded-lg p-6 mb-4">
                      <div className="flex justify-between items-start mb-4">
                        <h4 className="text-lg font-medium text-gray-900">Education #{index + 1}</h4>
                        <button
                          onClick={() => {
                            setResume(prev => prev ? {
                              ...prev,
                              education: prev.education.filter(e => e.id !== edu.id)
                            } : null);
                          }}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="space-y-4">
                        <input
                          placeholder="Institution Name"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          value={edu.institution}
                          onChange={(e) => {
                            const newEdu = [...resume.education];
                            newEdu[index].institution = e.target.value;
                            setResume({...resume, education: newEdu});
                          }}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <input
                            placeholder="Degree"
                            className="px-4 py-2 border border-gray-300 rounded-lg"
                            value={edu.degree}
                            onChange={(e) => {
                              const newEdu = [...resume.education];
                              newEdu[index].degree = e.target.value;
                              setResume({...resume, education: newEdu});
                            }}
                          />
                          <input
                            placeholder="Field of Study"
                            className="px-4 py-2 border border-gray-300 rounded-lg"
                            value={edu.field}
                            onChange={(e) => {
                              const newEdu = [...resume.education];
                              newEdu[index].field = e.target.value;
                              setResume({...resume, education: newEdu});
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Skills */}
              {activeSection === 'skills' && (
                <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-900">Skills</h3>
                    <button
                      onClick={addSkill}
                      className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Plus className="h-5 w-5" />
                      <span>Add Skill</span>
                    </button>
                  </div>
                  
                  {resume?.skills.map((skill, index) => (
                    <div key={skill.id} className="border border-gray-200 rounded-lg p-6 mb-4">
                      <div className="flex justify-between items-start mb-4">
                        <h4 className="text-lg font-medium text-gray-900">Skill #{index + 1}</h4>
                        <button
                          onClick={() => {
                            setResume(prev => prev ? {
                              ...prev,
                              skills: prev.skills.filter(s => s.id !== skill.id)
                            } : null);
                          }}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                      <div className="space-y-4">
                        <input
                          placeholder="Skill Name (e.g., JavaScript, Project Management)"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          value={skill.name}
                          onChange={(e) => {
                            const newSkills = [...resume.skills];
                            newSkills[index].name = e.target.value;
                            setResume({...resume, skills: newSkills});
                          }}
                        />
                        <select
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                          value={skill.level}
                          onChange={(e) => {
                            const newSkills = [...resume.skills];
                            newSkills[index].level = e.target.value;
                            setResume({...resume, skills: newSkills});
                          }}
                        >
                          <option value="Beginner">Beginner</option>
                          <option value="Intermediate">Intermediate</option>
                          <option value="Advanced">Advanced</option>
                          <option value="Expert">Expert</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
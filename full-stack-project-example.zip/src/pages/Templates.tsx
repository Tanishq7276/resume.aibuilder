import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, Star, Palette, Briefcase, GraduationCap, Code } from 'lucide-react';

interface Template {
  id: string;
  name: string;
  description: string;
  category: string;
  color: string;
  popular: boolean;
  free: boolean;
}

export function Templates() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const templates: Template[] = [
    {
      id: '1',
      name: 'Modern Professional',
      description: 'Clean, contemporary design perfect for tech and business roles',
      category: 'professional',
      color: 'bg-blue-500',
      popular: true,
      free: true
    },
    {
      id: '2',
      name: 'Creative Portfolio',
      description: 'Bold and artistic design for creatives and designers',
      category: 'creative',
      color: 'bg-purple-500',
      popular: true,
      free: true
    },
    {
      id: '3',
      name: 'Academic Excellence',
      description: 'Formal layout ideal for academic and research positions',
      category: 'academic',
      color: 'bg-green-500',
      popular: false,
      free: true
    },
    {
      id: '4',
      name: 'Minimalist',
      description: 'Simple, elegant design that focuses on content',
      category: 'minimal',
      color: 'bg-gray-500',
      popular: true,
      free: true
    },
    {
      id: '5',
      name: 'Executive',
      description: 'Premium design for senior leadership positions',
      category: 'professional',
      color: 'bg-indigo-500',
      popular: false,
      free: false
    },
    {
      id: '6',
      name: 'Tech Developer',
      description: 'Designed specifically for software developers and engineers',
      category: 'tech',
      color: 'bg-teal-500',
      popular: true,
      free: true
    },
    {
      id: '7',
      name: 'Marketing Pro',
      description: 'Dynamic layout for marketing and sales professionals',
      category: 'marketing',
      color: 'bg-pink-500',
      popular: false,
      free: true
    },
    {
      id: '8',
      name: 'Two Column',
      description: 'Modern two-column layout with sidebar',
      category: 'professional',
      color: 'bg-amber-500',
      popular: false,
      free: false
    }
  ];

  const categories = [
    { id: 'all', name: 'All Templates', icon: Palette },
    { id: 'professional', name: 'Professional', icon: Briefcase },
    { id: 'creative', name: 'Creative', icon: Palette },
    { id: 'academic', name: 'Academic', icon: GraduationCap },
    { id: 'tech', name: 'Tech', icon: Code },
    { id: 'minimal', name: 'Minimal', icon: Check }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center py-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Professional Resume Templates</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Choose from our collection of professionally designed templates. All templates are ATS-friendly and optimized for success.
        </p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <input
                type="text"
                placeholder="Search templates..."
                className="w-full px-4 py-3 pl-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <div className="absolute left-4 top-3.5">
                <Palette className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{category.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredTemplates.map((template) => (
          <div
            key={template.id}
            className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-xl transition-shadow"
          >
            {/* Template Preview */}
            <div className={`h-48 ${template.color} relative`}>
              {template.popular && (
                <div className="absolute top-4 left-4 bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
                  <Star className="h-3 w-3" />
                  <span>Popular</span>
                </div>
              )}
              {!template.free && (
                <div className="absolute top-4 right-4 bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                  Premium
                </div>
              )}
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-4">
                <h3 className="font-semibold text-gray-900">{template.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{template.category}</p>
              </div>
            </div>

            {/* Template Info */}
            <div className="p-6">
              <p className="text-gray-600 mb-4">{template.description}</p>
              
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  {template.free ? (
                    <span className="text-green-600 font-semibold">Free</span>
                  ) : (
                    <span className="text-purple-600 font-semibold">Premium</span>
                  )}
                </div>
                <div className="flex items-center space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-4 w-4 ${
                        star <= 4 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Link
                  to={`/builder?template=${template.id}`}
                  className={`block text-center py-3 rounded-lg font-medium transition-colors ${
                    template.free
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-purple-600 text-white hover:bg-purple-700'
                  }`}
                >
                  {template.free ? 'Use This Template' : 'Upgrade to Use'}
                </Link>
                
                <button className="w-full text-center py-2 text-gray-600 hover:text-gray-900">
                  Preview Template
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Template Features */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl shadow-lg p-8 border border-blue-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Why Our Templates Work</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">ATS Optimized</h3>
            <p className="text-gray-600">All templates are designed to pass through Applicant Tracking Systems</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Star className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Professional Design</h3>
            <p className="text-gray-600">Created by professional designers to impress recruiters</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Palette className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Fully Customizable</h3>
            <p className="text-gray-600">Easily customize colors, fonts, and layouts to match your style</p>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="text-center py-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Can't Find What You're Looking For?</h2>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          Our template library is constantly growing. Request a specific template or design your own from scratch.
        </p>
        <div className="flex justify-center space-x-4">
          <Link
            to="/builder"
            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-colors"
          >
            Start from Scratch
          </Link>
          <button className="bg-white text-gray-800 px-8 py-3 rounded-lg font-semibold text-lg border border-gray-300 hover:bg-gray-50 transition-colors">
            Request Template
          </button>
        </div>
      </div>
    </div>
  );
}
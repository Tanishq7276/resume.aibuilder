import express from 'express';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for resumes
let resumes = [];

// Resume data structure
const defaultResume = {
  id: '',
  personalInfo: {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    linkedin: '',
    github: '',
    portfolio: '',
    summary: ''
  },
  experience: [],
  education: [],
  skills: [],
  projects: [],
  certifications: []
};

// Get all resumes
app.get('/api/resumes', (req, res) => {
  res.json(resumes);
});

// Get single resume
app.get('/api/resumes/:id', (req, res) => {
  const resume = resumes.find(r => r.id === req.params.id);
  if (!resume) {
    return res.status(404).json({ error: 'Resume not found' });
  }
  res.json(resume);
});

// Create new resume
app.post('/api/resumes', (req, res) => {
  const newResume = {
    ...defaultResume,
    ...req.body,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  resumes.push(newResume);
  res.status(201).json(newResume);
});

// Update resume
app.put('/api/resumes/:id', (req, res) => {
  const index = resumes.findIndex(r => r.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Resume not found' });
  }
  
  resumes[index] = {
    ...resumes[index],
    ...req.body,
    updatedAt: new Date().toISOString()
  };
  
  res.json(resumes[index]);
});

// Delete resume
app.delete('/api/resumes/:id', (req, res) => {
  const index = resumes.findIndex(r => r.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Resume not found' });
  }
  
  resumes.splice(index, 1);
  res.status(204).send();
});

// Generate PDF endpoint (mock for now)
app.post('/api/resumes/:id/generate-pdf', (req, res) => {
  const resume = resumes.find(r => r.id === req.params.id);
  if (!resume) {
    return res.status(404).json({ error: 'Resume not found' });
  }
  
  // In a real app, you would generate PDF here
  // For now, return success with mock data
  res.json({
    success: true,
    message: 'PDF generated successfully',
    downloadUrl: `/api/resumes/${resume.id}/download`,
    resumeId: resume.id
  });
});

// Download PDF (mock)
app.get('/api/resumes/:id/download', (req, res) => {
  res.json({
    success: true,
    message: 'This would be the PDF file in a real implementation'
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
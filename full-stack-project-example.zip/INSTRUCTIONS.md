# How to Run the Resume Builder Application

## Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the full application (both frontend and backend):**
   ```bash
   npm run dev:full
   ```

   This will start:
   - Frontend at: http://localhost:5173
   - Backend API at: http://localhost:3001

## Alternative: Run Separately

### Start Backend Server:
```bash
npm run server
```
Backend runs on: http://localhost:3001

### Start Frontend Development Server:
```bash
npm run dev
```
Frontend runs on: http://localhost:5173

## Application Features

### 1. Home Page (http://localhost:5173)
- Landing page with application overview
- Quick start buttons
- Feature highlights

### 2. Dashboard (http://localhost:5173/dashboard)
- View all your resumes
- Create new resumes
- Edit/Delete existing resumes
- Download as PDF
- Resume statistics

### 3. Resume Builder (http://localhost:5173/builder)
- Create new resumes
- Edit existing resumes
- Multiple sections:
  - Personal Information
  - Work Experience
  - Education
  - Skills
  - Projects
  - Certifications
- Real-time preview
- Save functionality
- PDF generation

### 4. Templates (http://localhost:5173/templates)
- Browse professional templates
- Filter by category
- Preview templates
- Start with template

## API Endpoints

The backend provides these REST API endpoints:

### Resume Management
- `GET    /api/resumes` - List all resumes
- `GET    /api/resumes/:id` - Get specific resume
- `POST   /api/resumes` - Create new resume
- `PUT    /api/resumes/:id` - Update resume
- `DELETE /api/resumes/:id` - Delete resume
- `POST   /api/resumes/:id/generate-pdf` - Generate PDF

### Health Check
- `GET    /api/health` - Check server status

## Data Storage

- Uses in-memory storage (data resets on server restart)
- In production, you would connect to a database

## Building for Production

```bash
npm run build
```

This creates optimized production files in the `dist/` folder.

## Troubleshooting

### Port Already in Use
If port 3001 is already in use, change it in:
1. `.env` file (PORT variable)
2. `src/utils/api.ts` (API_URL)
3. `src/pages/*.tsx` files (API_URL imports)

### CORS Issues
CORS is already configured in `server.js`. If you have issues:
- Check that backend is running on port 3001
- Check that frontend is making requests to correct URL

### TypeScript Errors
Run type checking:
```bash
npx tsc --noEmit
```

## Next Steps for Production

1. **Add Database:** Replace in-memory storage with MongoDB/PostgreSQL
2. **Authentication:** Add user login/signup
3. **File Storage:** Store generated PDFs
4. **Email Integration:** Send resumes via email
5. **Deployment:** Deploy to hosting service (Render, Railway, Vercel, etc.)

## Support

The application is fully functional with:
- Complete frontend React application
- Complete backend Express API
- Responsive design
- TypeScript support
- Real-time editing
- PDF generation capability